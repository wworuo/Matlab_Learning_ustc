%homework2.1
clc;
clear;
A =1:10;
A = A';
A = repmat(A,1,10);
result = A + A';
